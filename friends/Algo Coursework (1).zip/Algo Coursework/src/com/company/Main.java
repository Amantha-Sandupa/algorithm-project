package com.company;

import java.io.*;
/*
    Main Class
    Student ID - w1810803
    Student name - Dineth Chamika
 */
public class Main {

    public static void main(String[] args) throws IOException {
       PuzzleClass findMyFile = new PuzzleClass();
       findMyFile.readFile();
       GraphClass graph = new GraphClass();
       findMyFile.createGraph(graph);
    }
}

