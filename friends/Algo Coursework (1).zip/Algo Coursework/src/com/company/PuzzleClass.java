package com.company;

import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

/*
    PuzzleClass where I Read My input File and Insert it Into a 2D array
    And create the graph from 2D array
    Student ID - w1810803
    Student name - Dineth Chamika
 */

public class PuzzleClass {
    private int COLUMNS;
    private int ROWS;
    private PointCoordinate[][] matrixMap;
    private PointCoordinate startPoint;
    private PointCoordinate endPoint;
    private int maxWidth;
    private int maxHeight;
    /*
     * Read the File that give the input as from the chooseMyFile method
     * and Insert its Data Into  2D array
     */
    public void readFile() throws IOException {
        try {

            File myFile = new File(String.valueOf(chooseMyFile()));
            Scanner myReader = new Scanner(myFile);
            Scanner scanner = new Scanner(myFile);
            COLUMNS = scanner.nextLine().length();
            int rowCount = 1;
            while(scanner.hasNext()){
                scanner.nextLine();
               rowCount++;
            }
            ROWS                = rowCount;
            int rowNumber       = 0;
            int characterNumber = 0;
            matrixMap           = new PointCoordinate[ROWS][COLUMNS];
            maxHeight           = ROWS;
            maxWidth            = COLUMNS;

            while (myReader.hasNext()) {
                String data = myReader.nextLine();
                for (int i = 0; i < COLUMNS; i++){
                    PointCoordinate pointCoordinate = new PointCoordinate(characterNumber,i,rowNumber,data.charAt(i));
                    matrixMap[rowNumber][i] = pointCoordinate;
                    if(pointCoordinate.getCharacter().equals('S')){
                        startPoint = pointCoordinate;// If programme found a character as S assign that as the starting point
                    }
                    if(pointCoordinate.getCharacter().equals('F')){
                        endPoint = pointCoordinate;// If programme found a character as F assign that as the Ending point
                    }
                    characterNumber++;
                }
                rowNumber++;
            }
            for (int i = 0; i < COLUMNS; i++){
                System.out.print("[");
                for (int j = 0; j < ROWS; j++){
                    System.out.print(matrixMap[i][j].getCharacter()+", ");
                }
                System.out.print("]");
                System.out.println();

            }
            myReader.close();
            scanner.close();
            System.out.println("");
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }

    public GraphClass createGraph(GraphClass graph) {
        Stack<Integer> stack = new Stack<Integer>();
        List<Integer> visited = new ArrayList<>();
        PointCoordinate oldPoint = startPoint;
        stack.push(oldPoint.getId());
        graph.addVertex(oldPoint.getId());
        boolean isPathVisible = false;
        while (!stack.isEmpty()) {
            int vertexId = stack.pop();
            visited.add(vertexId);
            oldPoint = getPointFromMatrixArray(vertexId);
            if (finishVertexInPath(oldPoint)) {
                graph.addVertex(endPoint.getId());
                graph.addEdge(vertexId, endPoint.getId());
                isPathVisible = true;
                stack.clear();
                break;
            } else {
                if (canTravelUp(oldPoint)) {
                    PointCoordinate newPoint = goUp(oldPoint);
                    if (!visited.contains(newPoint.getId())) {
                        stack.push(newPoint.getId());
                        graph.addVertex(newPoint.getId());
                        graph.addEdge(vertexId, newPoint.getId());
                    }
                }
                if (canTravelDown(oldPoint)) {
                    PointCoordinate newPoint = goDown(oldPoint);
                    if (!visited.contains(newPoint.getId())) {
                        stack.push(newPoint.getId());
                        graph.addVertex(newPoint.getId());
                        graph.addEdge(vertexId, newPoint.getId());
                    }
                }
                if (canTravelRight(oldPoint)) {
                    PointCoordinate newPoint = goRight(oldPoint);
                    if (!visited.contains(newPoint.getId())) {
                        stack.push(newPoint.getId());
                        graph.addVertex(newPoint.getId());
                        graph.addEdge(vertexId, newPoint.getId());
                    }
                }
                if (canTravelLeft(oldPoint)) {
                    PointCoordinate newPoint = goLeft(oldPoint);
                    if (!visited.contains(newPoint.getId())) {
                        stack.push(newPoint.getId());
                        graph.addVertex(newPoint.getId());
                        graph.addEdge(vertexId, newPoint.getId());
                    }
                }
            }
        }
        if (isPathVisible) {
            return graph;
        } else {
            return null;
        }
    }

    public PointCoordinate getPointFromMatrixArray(int vertexId) {
        for (int i = 0; i < matrixMap.length; i++) {
            for (int j = 0; j < matrixMap[i].length; j++) {
                if (matrixMap[i][j].getId() == vertexId) {
                    return matrixMap[i][j];
                }
            }
        }
        return null;
    }

    public PointCoordinate getPointFromMatrixArray(int x, int y) {
        for (int i = 0; i < matrixMap.length; i++) {
            for (int j = 0; j < matrixMap[i].length; j++) {
                if (matrixMap[i][j].getX() == x && matrixMap[i][j].getY() == y) {
                    return matrixMap[i][j];
                }
            }
        }
        return null;
    }
    public boolean finishVertexInPath(PointCoordinate pointCoordinate) {
        if (pointCoordinate.getId() == endPoint.getId()) {
            return true;
        }
        if (!(pointCoordinate.getX() == endPoint.getX() || pointCoordinate.getY() == endPoint.getY())) {
            return false;
        }
        int start;
        int end;
        if (pointCoordinate.getX() == endPoint.getX()) {
            if (pointCoordinate.getY() < endPoint.getY()) {
                start = pointCoordinate.getY();
                end = endPoint.getY();
            } else {
                start = endPoint.getY();
                end = pointCoordinate.getY();
            }
            for (int i = start; i <= end; i++) {
                PointCoordinate p = getPointFromMatrixArray(endPoint.getX(), i);
                if (p.getCharacter().equals('0')) {
                    return false;
                }
            }
        } else {
            if (pointCoordinate.getX() < endPoint.getX()) {
                start = pointCoordinate.getX();
                end = endPoint.getX();
            } else {
                start = endPoint.getX();
                end = pointCoordinate.getX();
            }
            for (int i = start; i <= end; i++) {
                PointCoordinate p = getPointFromMatrixArray(i, endPoint.getY());
                if (p.getCharacter().equals('0')) {
                    return false;
                }
            }
        }
        return true;
    }

    public PointCoordinate goUp(PointCoordinate pointCoordinate){
        PointCoordinate newCoordinate = pointCoordinate;
        while(canTravelUp(newCoordinate)){
            newCoordinate = matrixMap[newCoordinate.getY()-1][newCoordinate.getX()];
        }
        return newCoordinate;
    }

    public PointCoordinate goDown(PointCoordinate pointCoordinate){
        PointCoordinate newCoordinate = pointCoordinate;
        while(canTravelDown(newCoordinate)){
            newCoordinate = matrixMap[newCoordinate.getY()+1][newCoordinate.getX()];
        }
        return newCoordinate;
    }
    public PointCoordinate goLeft(PointCoordinate pointCoordinate){
        PointCoordinate newCoordinate = pointCoordinate;
        while(canTravelLeft(newCoordinate)){
            newCoordinate = matrixMap[newCoordinate.getY()][newCoordinate.getX()-1];
        }
        return newCoordinate;
    }
    public PointCoordinate goRight(PointCoordinate pointCoordinate){
        PointCoordinate newCoordinate = pointCoordinate;
        while(canTravelRight(newCoordinate)){
            newCoordinate = matrixMap[newCoordinate.getY()][newCoordinate.getX()+1];
        }
        return newCoordinate;
    }

    public boolean canTravelUp(PointCoordinate pointCoordinate){
        if (pointCoordinate.getY() == 0) {
            return false;
        }
        if (!(matrixMap[pointCoordinate.getY()-1][pointCoordinate.getX()].getCharacter().equals('0'))) {
            return true;
        }
        return false;
    }

    public boolean canTravelDown(PointCoordinate pointCoordinate){
        if(pointCoordinate.getY() == maxHeight-1){
            return false;
        }
        else if(!(matrixMap[pointCoordinate.getY()+1][pointCoordinate.getX()].getCharacter().equals('0'))){
            return true;
        }
        return false;
    }

    public boolean canTravelLeft(PointCoordinate pointCoordinate){
        if (pointCoordinate.getX() == 0) {
            return false;
        }
        else if (!(matrixMap[pointCoordinate.getY()][pointCoordinate.getX()-1].getCharacter().equals('0'))) {
            return true;
        }
        return false;
    }

    public boolean canTravelRight(PointCoordinate pointCoordinate){
        if(pointCoordinate.getX() == maxWidth-1){
            return false;
        }
        else if(!(matrixMap[pointCoordinate.getY()][pointCoordinate.getX()+1]).getCharacter().equals('0')){
            return true;
        }
        return false;
    }

    /*
     * The method to choose the Input File
     *
     */
    private File chooseMyFile() {
        FileDialog dialog = new FileDialog((Frame) null, "Select File to open");
        dialog.setMode(FileDialog.LOAD);
        dialog.setVisible(true);
        File[] file = dialog.getFiles();
        return file[0];
    }
}
