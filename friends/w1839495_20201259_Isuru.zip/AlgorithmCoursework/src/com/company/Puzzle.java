/*
 * UOW - w1839495
 * IIT - 20201259
 * Name - Isuru Dinuranga
*/

package com.company;

import java.io.*;
import java.util.Scanner;

public class Puzzle {
    private String fileName;
    private int columns;
    private int rows;
    Scanner scanner;
    File textFile;

    //Constructor
    public Puzzle(String fileName) {
        this.fileName = fileName;
    }


    public void columnsAndRows() throws IOException{
    textFile = new File(this.fileName);
    LineNumberReader readLineNumber = new LineNumberReader(new FileReader(textFile));
    String firstLine;

    scanner = new Scanner(textFile);

    firstLine = scanner.nextLine();

        for (int i = 0; i < firstLine.length(); i++) {
            columns++;
        }
        while (readLineNumber.readLine() != null){
            rows++;
        }
    }

    //Populate the 2d array
    public char[][] mainArray() throws FileNotFoundException{
        textFile = new File(fileName);
        scanner = new Scanner(textFile);
        char[][] maze = new char[rows][columns];

        for (int row = 0; scanner.hasNextLine() && row < rows; row++) {
            char[] stringTOChar = scanner.nextLine().toCharArray();
            for (int i = 0; i < columns && i < stringTOChar.length; i++) {
                maze[row][i] = stringTOChar[i];
            }
        }
        return maze;
    }
}
