/*
 * UOW - w1839495
 * IIT - 20201259
 * Name - Isuru Dinuranga
*/

package com.company;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        char[][] pathFinder;

        Puzzle puzzle = new Puzzle("maze10_1.txt"); //When we add the text file in to the its implement

        puzzle.columnsAndRows();
        pathFinder = puzzle.mainArray();

        for (int i = 0; i < pathFinder.length; i++) {
            System.out.println(pathFinder[i]);
        }
    }
}
